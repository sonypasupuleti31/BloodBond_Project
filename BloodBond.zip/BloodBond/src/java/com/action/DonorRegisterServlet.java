package com.action;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import com.db.DBConnection;
import javax.servlet.annotation.WebServlet;

@WebServlet("/DonorRegisterServlet")
public class DonorRegisterServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String name = request.getParameter("name");
        String email = request.getParameter("email"); // ✅ new email field
        String mobile = request.getParameter("mobile");
        String bloodGroup = request.getParameter("blood_group");
        String city = request.getParameter("city");
        String dob = request.getParameter("dob");
        String adhar = request.getParameter("adhar");
        String password = request.getParameter("password");
        String gender = request.getParameter("gender");

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO donor (name, email, mobile, blood_group, city, dob, adhar_no, password, gender) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
            );

            ps.setString(1, name);
            ps.setString(2, email); // ✅ added email
            ps.setString(3, mobile);
            ps.setString(4, bloodGroup);
            ps.setString(5, city);
            ps.setString(6, dob);
            ps.setString(7, adhar);
            ps.setString(8, password);
            ps.setString(9, gender);

            int i = ps.executeUpdate();

            if (i > 0) {
                out.println("<script>alert('Donor Registered Successfully!');window.location='login.jsp';</script>");
            } else {
                out.println("<script>alert('Registration Failed! Try Again');window.location='donor_register.jsp';</script>");
            }

        } catch (Exception e) {
            e.printStackTrace();
            out.println("<script>alert('Error: " + e.getMessage() + "');window.location='donor_register.jsp';</script>");
        }
    }
}
