package com.action;

import com.db.DBConnection;
import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/DonorResponseServlet")
public class DonorResponseServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("donorId") == null) {
            response.sendRedirect("donor_login.jsp");
            return;
        }

        int donorId = (Integer) session.getAttribute("donorId");
        int requestId = Integer.parseInt(request.getParameter("requestId"));

        try (Connection con = DBConnection.getConnection()) {

            // 1️⃣ Fetch receiver_id and hospital_id from blood_requests
            PreparedStatement psFetch = con.prepareStatement(
                "SELECT receiver_id, hospital_id FROM blood_requests WHERE id = ?"
            );
            psFetch.setInt(1, requestId);

            ResultSet rs = psFetch.executeQuery();

            if (!rs.next()) {
                response.sendRedirect("blood_needed.jsp?msg=invalid_request");
                return;
            }

            int receiverId = rs.getInt("receiver_id");
            int hospitalId = rs.getInt("hospital_id");

            rs.close();
            psFetch.close();

            // 2️⃣ Insert into donor_response with ALL required fields
            PreparedStatement psInsert = con.prepareStatement(
                "INSERT INTO donor_response " +
                "(donor_id, receiver_id, hospital_id, request_id, status) " +
                "VALUES (?, ?, ?, ?, 'PENDING')"
            );

            psInsert.setInt(1, donorId);
            psInsert.setInt(2, receiverId);
            psInsert.setInt(3, hospitalId);
            psInsert.setInt(4, requestId);

            psInsert.executeUpdate();
            psInsert.close();

            response.sendRedirect("blood_needed.jsp?msg=responded");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("blood_needed.jsp?msg=error");
        }
    }
}
