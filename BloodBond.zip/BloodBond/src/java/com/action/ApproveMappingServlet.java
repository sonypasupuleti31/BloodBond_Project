package com.action;

import com.db.DBConnection;
import com.util.EmailUtil;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ApproveMappingServlet")
public class ApproveMappingServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int requestId = Integer.parseInt(request.getParameter("requestId"));
        int donorId   = Integer.parseInt(request.getParameter("donorId"));

        try (Connection con = DBConnection.getConnection()) {

            /* 1️⃣ Update donor_response (Admin approval) */
            PreparedStatement ps1 = con.prepareStatement(
                "UPDATE donor_response " +
                "SET status='APPROVED' " +
                "WHERE request_id=? AND donor_id=?"
            );
            ps1.setInt(1, requestId);
            ps1.setInt(2, donorId);
            ps1.executeUpdate();
            ps1.close();

            /* 2️⃣ Update blood_requests */
            PreparedStatement ps2 = con.prepareStatement(
                "UPDATE blood_requests " +
                "SET donor_id=?, status='ADMIN_APPROVED' " +
                "WHERE id=?"
            );
            ps2.setInt(1, donorId);
            ps2.setInt(2, requestId);
            ps2.executeUpdate();
            ps2.close();

            /* 3️⃣ Fetch receiver email + hospital name */
            PreparedStatement ps3 = con.prepareStatement(
                "SELECT r.email, r.name, h.hospital_name " +
                "FROM receiver r " +
                "JOIN blood_requests br ON r.id = br.receiver_id " +
                "JOIN hospital h ON br.hospital_id = h.hospital_id " +
                "WHERE br.id=?"
            );
            ps3.setInt(1, requestId);

            ResultSet rs = ps3.executeQuery();

            if (rs.next()) {

                String receiverEmail = rs.getString("email");
                String receiverName  = rs.getString("name");
                String hospitalName  = rs.getString("hospital_name");

                /* 4️⃣ Send email to RECEIVER */
                String subject = "Blood Donor Found – Request Approved";
                String message =
                        "Dear " + receiverName + ",\n\n" +
                        "Good news!\n\n" +
                        "A suitable blood donor has been approved for your request.\n\n" +
                        "Hospital: " + hospitalName + "\n\n" +
                        "Please visit the hospital to proceed with the blood donation.\n\n" +
                        "Regards,\n" +
                        "BloodBond Team";

                EmailUtil.sendEmail(receiverEmail, subject, message);

                /* 5️⃣ Mark request as EMAIL_SENT */
                PreparedStatement ps4 = con.prepareStatement(
                    "UPDATE blood_requests SET status='EMAIL_SENT' WHERE id=?"
                );
                ps4.setInt(1, requestId);
                ps4.executeUpdate();
                ps4.close();
            }

            rs.close();
            ps3.close();

            response.sendRedirect("map_donor_receiver.jsp?msg=approved");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("map_donor_receiver.jsp?msg=error");
        }
    }
}
