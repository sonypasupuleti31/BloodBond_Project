package com.action;

import com.db.DBConnection;
import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/SendRequestServlet")
public class SendRequestServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        // 🔐 SAFETY CHECK (VERY IMPORTANT)
        if (session == null || session.getAttribute("receiverId") == null) {
            response.sendRedirect("receiver_login.jsp");
            return;
        }

        int receiverId = (Integer) session.getAttribute("receiverId");

        String pid = request.getParameter("patientId");
        if (pid == null || pid.isEmpty()) {
            response.sendRedirect("sendRequest.jsp?msg=selectPatient");
            return;
        }

        int patientId = Integer.parseInt(pid);

        try (Connection con = DBConnection.getConnection()) {

            // 1️⃣ Fetch hospital of receiver
            PreparedStatement ps1 = con.prepareStatement(
                "SELECT hospital_id FROM receiver WHERE id=?"
            );
            ps1.setInt(1, receiverId);

            ResultSet rs = ps1.executeQuery();

            if (!rs.next()) {
                response.sendRedirect("sendRequest.jsp?msg=noHospital");
                return;
            }

            int hospitalId = rs.getInt("hospital_id");

            // 2️⃣ Insert blood request
            PreparedStatement ps2 = con.prepareStatement(
                "INSERT INTO blood_requests " +
                "(receiver_id, patient_id, hospital_id, blood_group, status) " +
                "SELECT ?, ?, ?, blood_group, 'PENDING' FROM patient WHERE patient_id=?"
            );

            ps2.setInt(1, receiverId);
            ps2.setInt(2, patientId);
            ps2.setInt(3, hospitalId);
            ps2.setInt(4, patientId);

            ps2.executeUpdate();

            response.sendRedirect("sendRequest.jsp?msg=success");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("sendRequest.jsp?msg=error");
        }
    }
}
