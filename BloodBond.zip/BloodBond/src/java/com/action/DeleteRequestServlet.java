package com.action;

import com.db.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/DeleteRequestServlet")
public class DeleteRequestServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("email") == null) {
            response.sendRedirect("receiver_login.jsp");
            return;
        }

        String email = (String) session.getAttribute("email");
        String requestId = request.getParameter("id");

        if (requestId == null || requestId.isEmpty()) {
            response.sendRedirect("status.jsp");
            return;
        }

        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                "DELETE FROM blood_requests WHERE id=? AND email=?"
            );
            ps.setInt(1, Integer.parseInt(requestId));
            ps.setString(2, email);
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Corrected this line
        response.sendRedirect("status.jsp");
    }
}
