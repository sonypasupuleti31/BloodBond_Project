package com.action;

import com.db.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/AddPatientServlet")
public class AddPatientServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("hospitalId") == null) {
            response.sendRedirect("receiver_login.jsp");
            return;
        }

        int hospitalId = (Integer) session.getAttribute("hospitalId");

        String patientName = request.getParameter("patientName");
        String bloodGroup = request.getParameter("bloodGroup");
        String conditionDetails = request.getParameter("conditionDetails");

        try (Connection con = DBConnection.getConnection()) {

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO patient (patient_name, blood_group, hospital_id, condition_details) " +
                "VALUES (?, ?, ?, ?)"
            );

            ps.setString(1, patientName);
            ps.setString(2, bloodGroup);
            ps.setInt(3, hospitalId);
            ps.setString(4, conditionDetails);

            ps.executeUpdate();

            response.sendRedirect("add_patient.jsp?msg=success");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("add_patient.jsp?msg=error");
        }
    }
}
