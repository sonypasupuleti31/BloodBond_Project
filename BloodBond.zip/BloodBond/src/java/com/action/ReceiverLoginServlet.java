package com.action;

import com.db.DBConnection;
import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ReceiverLoginServlet")
public class ReceiverLoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try (Connection con = DBConnection.getConnection()) {

            PreparedStatement ps = con.prepareStatement(
                "SELECT id, email, hospital_id FROM receiver WHERE email=? AND password=?"
            );
            ps.setString(1, email);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                HttpSession session = request.getSession(true);

                // ✅ REQUIRED for new flow
                session.setAttribute("receiverId", rs.getInt("id"));
                session.setAttribute("receiverEmail", rs.getString("email"));
                session.setAttribute("hospitalId", rs.getInt("hospital_id"));

                response.sendRedirect("receiver_home.jsp");

            } else {
                response.getWriter().println(
                    "<script>alert('Invalid login!');window.location='receiver_login.jsp';</script>"
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
