package com.action;

import com.db.DBConnection;
import java.io.IOException;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/AddHospitalServlet")
public class AddHospitalServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("hospitalName");
        String city = request.getParameter("city");
        String email = request.getParameter("email");
        String contact = request.getParameter("contact");

        try (Connection con = DBConnection.getConnection()) {

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO hospital (hospital_name, city, email, contact) VALUES (?, ?, ?, ?)"
            );
            ps.setString(1, name);
            ps.setString(2, city);
            ps.setString(3, email);
            ps.setString(4, contact);

            ps.executeUpdate();
            response.sendRedirect("add_hospital.jsp?msg=success");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("add_hospital.jsp?msg=error");
        }
    }
}
