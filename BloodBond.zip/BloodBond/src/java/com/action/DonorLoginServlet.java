/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.action;

import com.db.DBConnection;
import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/DonorLoginServlet")
public class DonorLoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try (Connection con = DBConnection.getConnection()) {

            PreparedStatement ps = con.prepareStatement(
                "SELECT id, email,blood_group FROM donor WHERE email=? AND password=?"
            );
            ps.setString(1, email);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                HttpSession session = request.getSession(true);

                // ✅ REQUIRED for blood_needed.jsp
                session.setAttribute("donorId", rs.getInt("id"));
                session.setAttribute("donorEmail", rs.getString("email"));
                session.setAttribute("donorBloodGroup", rs.getString("blood_group"));

                response.sendRedirect(request.getContextPath() + "/blood_needed.jsp");

            } else {
                response.getWriter().println(
                    "<script>alert('Invalid login!');window.location='donor_login.jsp';</script>"
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
