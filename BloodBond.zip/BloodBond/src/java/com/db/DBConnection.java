/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.db;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author admin
 */
public class DBConnection {
    
    public static Connection con=null;
    
        public static  Connection getConnection(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
             Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/bloodbond","root","root");
//               Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/abc","root","root");

            if(con!=null){
                return con;
            }
            else{
             return con;
            }}
        catch(Exception e){
            System.out.println(e);
        }
    return con;}
}
