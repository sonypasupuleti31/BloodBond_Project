<%@ page contentType="text/html" pageEncoding="UTF-8"%>
<%
    HttpSession sess = request.getSession(false);

    if (sess == null || sess.getAttribute("receiverId") == null) {
        response.sendRedirect("receiver_login.jsp");
        return;
    }

    String receiverEmail = (String) sess.getAttribute("receiverEmail");
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Receiver Home</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; background: #f8f9fa; margin: 0; padding: 0; }
        .container { width: 80%; margin: 40px auto; background: #fff; padding: 30px; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        h2 { color: #d63031; text-align: center; margin-bottom: 20px; }
        p { line-height: 1.6; margin-bottom: 15px; }
        ul { margin-left: 20px; }
        li { margin-bottom: 10px; }
        a.button { display: inline-block; margin-top: 20px; background-color: #28a745; color: white; padding: 10px 15px; border-radius: 5px; text-decoration: none; }
        a.button:hover { background-color: #218838; }
    </style>
</head>
<body>

<jsp:include page="receiver_menu.jsp"></jsp:include>

<div class="container">
    <h2>Welcome, <%= receiverEmail %></h2>

    <p>Blood donation is a noble act that helps save lives. Here are some benefits for both donors and recipients:</p>

    <ul>
        <li>Helps save the life of someone in need of blood.</li>
        <li>Regular donation improves health by stimulating new blood cell production.</li>
        <li>Reduces the risk of heart disease.</li>
        <li>Boosts emotional well-being.</li>
        <li>Promotes a culture of helping others.</li>
    </ul>

    <p style="text-align:center;">
        <a class="button" href="sendRequest.jsp">Request Blood</a>
    </p>
</div>

</body>
</html>
