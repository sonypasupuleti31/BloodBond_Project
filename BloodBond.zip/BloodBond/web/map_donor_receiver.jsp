<%@ page import="java.sql.*, com.db.DBConnection" %>
<%@ page contentType="text/html;charset=UTF-8" %>

<!DOCTYPE html>
<html>
<head>
    <title>Map Donor and Receiver - Admin</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #fff8f6; margin: 0; }
        .container { width: 90%; margin: 40px auto; background: #fff; padding: 25px; border-radius: 10px; box-shadow: 0 3px 10px rgba(0,0,0,0.1); }
        h2 { text-align: center; color: #B30000; margin-bottom: 25px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: center; }
        th { background-color: #B30000; color: white; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        input[type="submit"] { background-color: #28a745; border: none; color: white; padding: 6px 12px; border-radius: 5px; cursor: pointer; }
    </style>
</head>
<body>

<jsp:include page="admin_menu.jsp"/>

<div class="container">
    <h2>Pending Donor Approvals</h2>

<%
    try (Connection con = DBConnection.getConnection()) {

        PreparedStatement ps = con.prepareStatement(
            "SELECT " +
            "dr.id AS response_id, " +
            "br.id AS request_id, " +
            "d.id AS donor_id, d.email AS donor_email, " +
            "p.patient_name, p.blood_group, " +
            "h.hospital_name, dr.status " +
            "FROM donor_response dr " +
            "JOIN blood_requests br ON dr.request_id = br.id " +
            "JOIN donor d ON dr.donor_id = d.id " +
            "JOIN patient p ON br.patient_id = p.patient_id " +
            "JOIN hospital h ON br.hospital_id = h.hospital_id " +
            "WHERE dr.status = 'PENDING'"
        );

        ResultSet rs = ps.executeQuery();
%>

<table>
<tr>
    <th>Donor Email</th>
    <th>Patient</th>
    <th>Blood Group</th>
    <th>Hospital</th>
    <th>Status</th>
    <th>Action</th>
</tr>

<%
    boolean found = false;
    while (rs.next()) {
        found = true;
%>
<tr>
    <td><%= rs.getString("donor_email") %></td>
    <td><%= rs.getString("patient_name") %></td>
    <td><%= rs.getString("blood_group") %></td>
    <td><%= rs.getString("hospital_name") %></td>
    <td><%= rs.getString("status") %></td>
    <td>
        <form action="ApproveMappingServlet" method="post">
            <input type="hidden" name="requestId" value="<%= rs.getInt("request_id") %>">
            <input type="hidden" name="donorId" value="<%= rs.getInt("donor_id") %>">
            <input type="submit" value="Approve">
        </form>
    </td>
</tr>
<%
    }

    if (!found) {
%>
<tr>
    <td colspan="6">No pending donor approvals.</td>
</tr>
<%
    }
%>
</table>

<%
        rs.close();
        ps.close();
    } catch (Exception e) {
        e.printStackTrace();
        out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
    }
%>

</div>
</body>
</html>
