<%@ page import="java.sql.*, com.db.DBConnection" %>
<%@ page contentType="text/html" pageEncoding="UTF-8"%>

<%
    HttpSession sess = request.getSession(false);
    if (sess == null || sess.getAttribute("receiverId") == null) {
        response.sendRedirect("receiver_login.jsp");
        return;
    }

    int hospitalId = (Integer) sess.getAttribute("hospitalId");
    String receiverEmail = (String) sess.getAttribute("receiverEmail");
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>My Blood Requests</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #fff8f6; margin: 0; padding: 0; }
        .container { max-width: 900px; margin: 40px auto; background: #fff; padding: 20px; border-radius: 12px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        h2 { text-align: center; color: #B30000; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: center; }
        th { background-color: #B30000; color: white; }
        td.status-pending { color: orange; font-weight: bold; }
        td.status-received { color: green; font-weight: bold; }
    </style>
</head>
<body>

<jsp:include page="receiver_menu.jsp"/>

<div class="container">
    <h2>My Blood Requests</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>Blood Group</th>
            <th>Status</th>
            <th>Requested At</th>
        </tr>

        <%
            try (Connection con = DBConnection.getConnection()) {

                PreparedStatement ps = con.prepareStatement(
                    "SELECT br.id, p.blood_group, br.status, br.created_at " +
                    "FROM blood_requests br " +
                    "JOIN patient p ON br.patient_id = p.patient_id " +
                    "WHERE br.hospital_id = ? " +
                    "ORDER BY br.created_at DESC"
                );

                ps.setInt(1, hospitalId);
                ResultSet rs = ps.executeQuery();

                while (rs.next()) {
                    String status = rs.getString("status");
                    String statusClass = status.equalsIgnoreCase("PENDING")
                            ? "status-pending" : "status-received";
        %>
                    <tr>
                        <td><%= rs.getInt("id") %></td>
                        <td><%= rs.getString("blood_group") %></td>
                        <td class="<%= statusClass %>"><%= status %></td>
                        <td><%= rs.getTimestamp("created_at") %></td>
                    </tr>
        <%
                }
                rs.close();
                ps.close();
            } catch (Exception e) {
                out.println("<tr><td colspan='4'>Error loading requests</td></tr>");
                e.printStackTrace();
            }
        %>
    </table>
</div>

</body>
</html>
