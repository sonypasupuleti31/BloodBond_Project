<%@ page import="java.sql.*, com.db.DBConnection" %>
<%@ page contentType="text/html" pageEncoding="UTF-8"%>

<%
    // 🔐 Donor session check
    HttpSession sess = request.getSession(false);
    if (sess == null || sess.getAttribute("donorId") == null) {
        response.sendRedirect("donor_login.jsp");
        return;
    }

    String donorEmail = (String) sess.getAttribute("donorEmail");
    String donorBloodGroup = (String) sess.getAttribute("donorBloodGroup"); // ✅ REQUIRED
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Blood Needed</title>
    <style>
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: #f8f9fa;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 90%;
            margin: 40px auto;
            background: #fff;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        h2 {
            color: #d63031;
            text-align: center;
        }
        h4 {
            text-align: center;
            color: #555;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th {
            background-color: #d63031;
            color: white;
            padding: 10px;
        }
        td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: center;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        input[type="submit"] {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 6px 10px;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #218838;
        }
        .status-donated {
            color: green;
            font-weight: bold;
        }
        .no-data {
            text-align: center;
            color: gray;
            padding: 20px;
        }
    </style>
</head>

<body>

<jsp:include page="donor_menu.jsp"/>

<div class="container">
    <h2>Blood Needed</h2>
    <h4>Welcome, <%= donorEmail %> ( <%= donorBloodGroup %> )</h4>

    <table>
        <tr>
            <th>Patient Name</th>
            <th>Blood Group</th>
            <th>Hospital</th>
            <th>Status</th>
            <th>Action</th>
        </tr>

        <%
            boolean found = false;

            try (Connection con = DBConnection.getConnection()) {

                PreparedStatement ps = con.prepareStatement(
                    "SELECT br.id, p.patient_name, p.blood_group, h.hospital_name, br.status " +
                    "FROM blood_requests br " +
                    "JOIN patient p ON br.patient_id = p.patient_id " +
                    "JOIN hospital h ON br.hospital_id = h.hospital_id " +
                    "WHERE br.status = 'PENDING' AND p.blood_group = ? " +   // ✅ FILTER
                    "ORDER BY br.created_at DESC"
                );

                ps.setString(1, donorBloodGroup);

                ResultSet rs = ps.executeQuery();

                while (rs.next()) {
                    found = true;
                    String status = rs.getString("status");
        %>
                    <tr>
                        <td><%= rs.getString("patient_name") %></td>
                        <td><%= rs.getString("blood_group") %></td>
                        <td><%= rs.getString("hospital_name") %></td>
                        <td><%= status %></td>
                        <td>
                            <form action="DonorResponseServlet" method="post" style="margin:0;">
                                <input type="hidden" name="requestId" value="<%= rs.getInt("id") %>">
                                <input type="submit" value="I'm Ready to Donate">
                            </form>
                        </td>
                    </tr>
        <%
                }
                rs.close();
                ps.close();
            } catch (Exception e) {
                e.printStackTrace();
        %>
                <tr>
                    <td colspan="5" class="no-data">Error loading blood requests</td>
                </tr>
        <%
            }

            if (!found) {
        %>
            <tr>
                <td colspan="5" class="no-data">
                    No blood requests available for your blood group
                </td>
            </tr>
        <%
            }
        %>
    </table>
</div>

</body>
</html>
