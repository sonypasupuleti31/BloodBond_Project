<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BloodBond - Smart Blood Donation System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Inter', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #FFF8F6;
            color: #2D2D2D;
        }

        header {
            background-color: #B30000; /* Blood red header */
            color: #FFFFFF;
            padding: 20px 0;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            width: 100%;
        }

        header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: 700;
            letter-spacing: 0.5px;
        }

        /* ✅ Full-width Navbar */
        nav {
            width: 100%;
            background-color: #FF6B6B; /* Light blood red nav */
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        nav ul {
            list-style: none;
            margin: 0 auto;
            padding: 12px 0;
            display: flex;
            justify-content: center;
            align-items: center;
            max-width: 1200px; /* Keeps content centered */
        }

        nav ul li {
            margin: 0 18px;
        }

        nav ul li a {
            color: #2D2D2D;
            text-decoration: none;
            font-size: 16px;
            font-weight: 500;
            transition: all 0.3s ease;
            padding: 8px 16px;
            border-radius: 6px;
        }

        nav ul li a:hover {
            color: #FFFFFF;
            background-color: #B30000;
        }

        @media (max-width: 768px) {
            header h1 {
                font-size: 20px;
                padding: 0 20px;
            }

            nav ul {
                flex-direction: column;
                padding: 10px 0;
            }

            nav ul li {
                margin: 8px 0;
            }

            nav ul li a {
                font-size: 15px;
                padding: 6px 12px;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>BloodBond - Smart Blood Donation Management System</h1>
    </header>

    <nav>
        <ul>
            <li><a href="index.jsp">Home</a></li>
            <li><a href="donor_register.jsp">Donor Register</a></li>
            <li><a href="receiver_register.jsp">Receiver Register</a></li>
            <li><a href="login.jsp">Login</a></li>
            <li><a href="admin_login.jsp">Admin</a></li>
        </ul>
    </nav>
</body>
</html>
