<%@ page import="java.sql.*, com.db.DBConnection" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Donor Home - BloodBond</title>
    <style>
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: #fff8f6;
            margin: 0;
        }
        .container {
            width: 85%;
            margin: 40px auto;
            background: #fff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        h2, h3 {
            color: #B30000;
            text-align: center;
        }
        p {
            text-align: justify;
            font-size: 15px;
            color: #444;
            line-height: 1.6;
            margin: 10px 0;
        }
        .logout-btn {
            text-align: right;
            margin-bottom: 10px;
        }
        .logout-btn a {
            color: #B30000;
            text-decoration: none;
            font-weight: bold;
        }
        .logout-btn a:hover {
            text-decoration: underline;
        }
        .info-box {
            background-color: #fff0f0;
            border-left: 5px solid #B30000;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
        }
        .benefits {
            margin-top: 25px;
        }
        .benefits ul {
            list-style-type: disc;
            margin: 10px 20px;
            color: #444;
        }
    </style>
</head>
<body>
    <jsp:include page="donor_menu.jsp"></jsp:include>

    <div class="container">

        <div class="logout-btn">
            <a href="logout.jsp">Logout</a>
        </div>

        <%
            String donorEmail = (String) session.getAttribute("email");
            if (donorEmail == null) {
                response.sendRedirect("donor_login.jsp");
                return;
            }

            Connection con = null;
            PreparedStatement ps = null;
            ResultSet rs = null;
            String donorName = "";

            try {
                con = DBConnection.getConnection();
                ps = con.prepareStatement("SELECT name FROM donor WHERE email = ?");
                ps.setString(1, donorEmail);
                rs = ps.executeQuery();

                if (rs.next()) {
                    donorName = rs.getString("name");
                }
            } catch (Exception e) {
                out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (ps != null) ps.close();
                    if (con != null) con.close();
                } catch (Exception ex) { ex.printStackTrace(); }
            }
        %>

        <h2>Welcome to BloodBond Donor Dashboard ❤️</h2>
        <h3>Hello, <%= donorName %> 👋</h3>

        <div class="info-box">
            <p>
                Thank you for joining <b>BloodBond</b>!  
                You’re not just a donor — you’re a true hero who helps save lives.  
                Every drop of your blood can bring hope to someone in need.
            </p>
        </div>

        <div class="benefits">
            <h3>Benefits of Donating Blood 🩸</h3>
            <ul>
                <li>Helps save lives and support emergency surgeries.</li>
                <li>Improves your heart health by maintaining iron balance.</li>
                <li>Encourages the production of new blood cells.</li>
                <li>Reduces stress and gives you a sense of satisfaction.</li>
                <li>It’s one of the simplest ways to make a big difference!</li>
            </ul>
        </div>

    </div>
</body>
</html>
