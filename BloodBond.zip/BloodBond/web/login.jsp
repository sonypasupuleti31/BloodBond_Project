<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BloodBond - Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #FFF8F6;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 500px;
            margin: 100px auto;
            text-align: center;
            background: #FFFFFF;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        h2 {
            color: #B30000;
            margin-bottom: 30px;
        }

        .login-btn {
            display: block;
            width: 100%;
            margin: 15px 0;
            padding: 14px 0;
            background-color: #B30000;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            font-weight: 600;
            text-decoration: none;
            transition: 0.3s;
        }

        .login-btn:hover {
            background-color: #FF6B6B;
        }
    </style>
</head>
<body>
    <jsp:include page="homemenu.jsp"></jsp:include>
    <div class="container">
        <h2>Select Login Type</h2>
        <a href="donor_login.jsp" class="login-btn">Donor Login</a>
        <a href="receiver_login.jsp" class="login-btn">Receiver Login</a>
    </div>
</body>
</html>
