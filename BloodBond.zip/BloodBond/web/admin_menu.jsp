<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BloodBond - Admin Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

    <style>
        /* --- Base Page --- */
        html, body {
            margin: 0;
            padding: 0;
            width: 100%;
            background-color: #FFF8F6;
            font-family: 'Inter', sans-serif;
            color: #2D2D2D;
        }

        /* --- Header --- */
        header {
            background-color: #B30000; /* Blood red */
            color: #FFFFFF;
            padding: 20px 0;
            text-align: center;
            width: 100%;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        header h1 {
            margin: 0;
            font-size: 26px;
            font-weight: 700;
            letter-spacing: 0.6px;
        }

        /* --- Navigation --- */
        nav {
            background-color: #FF6B6B; /* lighter blood red */
            width: 100%;
            margin: 0;
            box-shadow: 0 3px 6px rgba(0,0,0,0.1);
        }

        nav ol {
            list-style: none;
            margin: 0;
            padding: 12px 0;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
        }

        /* Each Nav Item */
        nav ol li {
            margin: 0 14px;
        }

        /* Nav Links */
        nav ol li a {
            text-decoration: none;
            color: #FFFFFF; /* Clear white for better readability */
            font-weight: 600;
            font-size: 16px;
            padding: 10px 20px;
            border-radius: 8px;
            background-color: rgba(179, 0, 0, 0.85);
            transition: all 0.3s ease;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
            display: inline-block;
        }

        /* Hover State */
        nav ol li a:hover {
            background-color: #B30000; /* Deep blood red */
            color: #FFF;
            transform: translateY(-2px);
        }

        /* Active Link */
        nav ol li.active a {
            background-color: #B30000;
            color: #FFF;
            box-shadow: 0 3px 6px rgba(0,0,0,0.2);
        }

        /* --- Responsive Design --- */
        @media (max-width: 768px) {
            header h1 {
                font-size: 20px;
                padding: 0 10px;
            }

            nav ol {
                flex-direction: column;
                padding: 10px 0;
            }

            nav ol li {
                margin: 8px 0;
            }

            nav ol li a {
                width: 80%;
                text-align: center;
            }
        }
    </style>
</head>

<body>
    <header>
        <h1>BloodBond - Admin Dashboard</h1>
    </header>

    <nav>
        <ol>
            <li class="active"><a href="admin_home.jsp">Home</a></li>
            <li><a href="map_donor_receiver.jsp">Map Donor & Receiver</a></li>
            <li><a href="view_all_donors.jsp">View Donors</a></li>
            <li><a href="view_all_receivers.jsp">View Receivers</a></li>
            <li><a href="add_hospital.jsp">Add Hospitals</a></li>
            <li><a href="logout.jsp">Logout</a></li>
        </ol>
    </nav>
</body>
</html>
