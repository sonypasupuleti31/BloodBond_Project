<%@ page import="java.sql.*, com.db.DBConnection" %>
<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>All Blood Requests - BloodBond</title>
    <style>
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: #fff8f6;
            margin: 0;
            padding: 20px;
        }
        .container {
            width: 90%;
            margin: auto;
            background: #fff;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #B30000;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: center;
        }
        th {
            background-color: #B30000;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>

<jsp:include page="admin_menu.jsp"/>

<div class="container">
    <h2>All Blood Requests</h2>

<%
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    try {
        con = DBConnection.getConnection();

        ps = con.prepareStatement(
            "SELECT " +
            "br.id, br.blood_group, br.status, br.created_at, " +
            "r.name AS receiver_name, r.email AS receiver_email, " +
            "p.patient_name, h.hospital_name " +
            "FROM blood_requests br " +
            "JOIN receiver r ON br.receiver_id = r.id " +
            "JOIN patient p ON br.patient_id = p.patient_id " +
            "JOIN hospital h ON br.hospital_id = h.hospital_id " +
            "ORDER BY br.created_at DESC"
        );

        rs = ps.executeQuery();
%>

<table>
<tr>
    <th>ID</th>
    <th>Receiver Name</th>
    <th>Receiver Email</th>
    <th>Patient Name</th>
    <th>Blood Group</th>
    <th>Hospital</th>
    <th>Status</th>
    <th>Requested On</th>
</tr>

<%
    boolean found = false;
    while (rs.next()) {
        found = true;
%>
<tr>
    <td><%= rs.getInt("id") %></td>
    <td><%= rs.getString("receiver_name") %></td>
    <td><%= rs.getString("receiver_email") %></td>
    <td><%= rs.getString("patient_name") %></td>
    <td><%= rs.getString("blood_group") %></td>
    <td><%= rs.getString("hospital_name") %></td>
    <td><%= rs.getString("status") %></td>
    <td><%= rs.getTimestamp("created_at") %></td>
</tr>
<%
    }

    if (!found) {
%>
<tr>
    <td colspan="8">No blood requests found.</td>
</tr>
<%
    }
%>

</table>

<%
    } catch (Exception e) {
        e.printStackTrace();
        out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
    } finally {
        try {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (con != null) con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
%>

</div>
</body>
</html>
