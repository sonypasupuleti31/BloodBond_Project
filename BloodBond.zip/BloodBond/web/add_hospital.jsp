<%@ page contentType="text/html;charset=UTF-8" %>
<html>
<head>
    <title>Add Hospital</title>
</head>
<body>

<jsp:include page="admin_menu.jsp"/>

<h2>Add Hospital</h2>

<form action="AddHospitalServlet" method="post">
    Hospital Name: <input type="text" name="hospitalName" required><br><br>
    City: <input type="text" name="city" required><br><br>
    Email: <input type="email" name="email"><br><br>
    Contact: <input type="text" name="contact"><br><br>

    <input type="submit" value="Add Hospital">
</form>

</body>
</html>
