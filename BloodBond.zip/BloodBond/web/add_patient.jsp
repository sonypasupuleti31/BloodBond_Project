<%@ page contentType="text/html" pageEncoding="UTF-8"%>
<%
    HttpSession sess = request.getSession(false);
    if (sess == null || sess.getAttribute("receiverId") == null) {
        response.sendRedirect("receiver_login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Add Patient</title>
    <style>
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: #FFF8F6;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #B30000;
            margin-bottom: 24px;
        }
        label {
            display: block;
            margin-bottom: 6px;
            font-weight: 600;
        }
        input, select, textarea, button {
            width: 100%;
            padding: 10px;
            margin-bottom: 16px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }
        button {
            background-color: #B30000;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #FF6B6B;
        }
    </style>
</head>
<body>

<jsp:include page="receiver_menu.jsp"/>

<div class="container">
    <h2>Add Patient</h2>

    <form action="AddPatientServlet" method="post">

        <label>Patient Name</label>
        <input type="text" name="patientName" required>

        <label>Blood Group</label>
        <select name="bloodGroup" required>
            <option value="">-- Select --</option>
            <option>A+</option><option>A-</option>
            <option>B+</option><option>B-</option>
            <option>O+</option><option>O-</option>
            <option>AB+</option><option>AB-</option>
        </select>
        <label>Hospital_id</label>
        <input type="text" name="hospital_id" required>

        <label>Condition Details</label>
        <textarea name="conditionDetails" rows="3"
                  placeholder="Optional medical condition details"></textarea>

        <button type="submit">Add Patient</button>
    </form>
</div>

</body>
</html>
