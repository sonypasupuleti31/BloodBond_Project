<%@ page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Receiver Menu - BloodBond</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #FFF8F6;
        }

        header {
            background-color: #B30000;
            color: white;
            text-align: center;
            padding: 20px 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }

        header h1 {
            margin: 0;
            font-size: 24px;
        }

        nav {
            background-color: #B30000;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }

        nav ol {
            list-style: none;
            display: flex;
            justify-content: center;
            margin: 0;
            padding: 10px 0;
        }

        nav ol li {
            margin: 0 20px;
        }

        nav ol li a {
            color: white;
            text-decoration: none;
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 6px;
            transition: all 0.3s ease;
        }

        nav ol li a:hover {
            background-color: #FF6B6B;
        }

        nav ol li.active a {
            background-color: #FF6B6B;
        }

        @media (max-width: 768px) {
            nav ol {
                flex-direction: column;
                padding: 10px 0;
            }
            nav ol li {
                margin: 8px 0;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>BloodBond - Smart Blood Donation Management System</h1>
    </header>

    <nav>
        <ol>
            <li class="active"><a href="receiver_home.jsp">Home</a></li>
            <li><a href="sendRequest.jsp">Send Request</a></li>
            <li><a href="status.jsp">Status</a></li>
            <li><a href="add_patient.jsp">Add Patient</a></li>
            <li><a href="logout.jsp">Logout</a></li>
        </ol>
    </nav>

</body>
</html>
