<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login - BloodBond</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

    <style>
        /* Global Page Styles */
        body {
            font-family: 'Inter', sans-serif;
            background-color: #FFF8F6;
            margin: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        /* Add some space below the nav bar */
        main {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            flex-grow: 1;
            height: calc(100vh - 140px); /* Ensures proper spacing below header/nav */
        }

        /* Login Box */
        .login-box {
            width: 350px;
            background: #fff;
            padding: 30px 25px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            text-align: center;
        }

        h2 {
            color: #B30000;
            margin-bottom: 20px;
            font-size: 22px;
        }

        input[type="text"],
        input[type="password"] {
            width: 90%;
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 15px;
        }

        input[type="submit"] {
            background-color: #B30000;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            margin-top: 12px;
            width: 100%;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #8B0000;
        }

        .error {
            color: red;
            margin-top: 10px;
            font-size: 14px;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .login-box {
                width: 85%;
            }
        }
    </style>
</head>
<body>

    <!-- Include the global navigation -->
    <jsp:include page="homemenu.jsp"></jsp:include>

    <main>
        <div class="login-box">
            <h2>Admin Login</h2>
            <form action="AdminLoginServlet" method="post">
                <input type="text" name="username" placeholder="Enter Username" required>
                <input type="password" name="password" placeholder="Enter Password" required>
                <input type="submit" value="Login">
            </form>

            <% 
                String error = request.getParameter("error");
                if (error != null) { 
            %>
                <p class="error">Invalid username or password!</p>
            <% } %>
        </div>
    </main>

</body>
</html>
