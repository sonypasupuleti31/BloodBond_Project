<%@ page import="java.sql.*, com.db.DBConnection" %>
<%@ page contentType="text/html" pageEncoding="UTF-8"%>

<%
    HttpSession sess = request.getSession(false);
    if (sess == null || sess.getAttribute("receiverId") == null) {
        response.sendRedirect("receiver_login.jsp");
        return;
    }

    int receiverId = (Integer) sess.getAttribute("receiverId");
    String receiverEmail = (String) sess.getAttribute("receiverEmail");
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Send Blood Request</title>
    <style>
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: #FFF8F6;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #B30000;
            margin-bottom: 24px;
        }
        label {
            display: block;
            margin-bottom: 6px;
            font-weight: 600;
        }
        select, button {
            width: 100%;
            padding: 12px;
            margin-bottom: 16px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }
        button {
            background-color: #B30000;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #FF6B6B;
        }
        .info {
            text-align: center;
            margin-bottom: 20px;
            color: #555;
        }
    </style>
</head>
<body>

<jsp:include page="receiver_menu.jsp"/>

<div class="container">
    <h2>Send Blood Request</h2>

    <div class="info">
        Logged in as: <b><%= receiverEmail %></b>
    </div>

    <form action="SendRequestServlet" method="post">

        <label for="patientId">Select Patient</label>
        <select name="patientId" id="patientId" required>
            <option value="">-- Select Patient --</option>

            <%
    try {
        Connection con = DBConnection.getConnection();
        PreparedStatement ps = con.prepareStatement(
            "SELECT patient_id, patient_name, blood_group " +
            "FROM patient WHERE hospital_id = ?"
        );

        int hospitalId = (Integer) sess.getAttribute("hospitalId");
        ps.setInt(1, hospitalId);

        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
%>
            <option value="<%= rs.getInt("patient_id") %>">
                <%= rs.getString("patient_name") %> ( <%= rs.getString("blood_group") %> )
            </option>
<%
        }
        rs.close();
        ps.close();
        con.close();
    } catch (Exception e) {
        out.println("<option>Error loading patients</option>");
        e.printStackTrace();
    }
%>

        </select>

        <button type="submit">Send Blood Request</button>
    </form>
</div>

</body>
</html>
