<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard - BloodBond</title>
    <style>
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: #fff8f6;
            margin: 0;
        }
        .container {
            width: 80%;
            margin: 60px auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        h2 {
            color: #B30000;
        }
        a {
            display: inline-block;
            margin: 15px;
            text-decoration: none;
            color: white;
            background: #B30000;
            padding: 10px 20px;
            border-radius: 6px;
        }
        a:hover {
            background: #8B0000;
        }
    </style>
</head>
<body>
    <%
        String adminUser = (String) session.getAttribute("adminUser");
        if (adminUser == null) {
            response.sendRedirect("admin_login.jsp");
            return;
        }
    %>
        <jsp:include page="admin_menu.jsp"></jsp:include>

    <div class="container">
        <h2>Welcome, <%= adminUser %> 👋</h2>
<!--        <a href="map_donor_receiver.jsp">Map Donor & Receiver</a>
        <a href="view_all_donors.jsp">View Donors</a>
        <a href="view_all_receivers.jsp">View Receivers</a>
        <a href="logout.jsp">Logout</a>-->
    </div>
</body>
</html>
