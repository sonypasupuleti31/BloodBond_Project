<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.*" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BloodBond - Receiver Registration</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #FFF8F6;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            background: #FFFFFF;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #B30000;
            margin-bottom: 24px;
        }
        form label {
            display: block;
            margin-bottom: 6px;
            font-weight: 600;
        }
        form input, form select {
            width: 100%;
            padding: 10px;
            margin-bottom: 16px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }
        form input[type="radio"] {
            width: auto;
            margin-right: 8px;
        }
        form button {
            background-color: #B30000;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
        }
        form button:hover {
            background-color: #FF6B6B;
        }
    </style>
</head>
<body>
    <jsp:include page="homemenu.jsp"></jsp:include>
    <div class="container">
        <h2>Receiver Registration</h2>
        <form action="ReceiverRegisterServlet" method="post">
            <label for="name">Full Name</label>
            <input type="text" id="name" name="name" required>

            <label for="mobile">Mobile Number</label>
            <input type="text" id="mobile" name="mobile" required pattern="[6789][0-9]{9}" title="Mobile Number Must 10 Digits">

            <label for="email">Email</label>
            <input type="email" id="email" name="email" required placeholder="example@gmail.com">

            <label for="blood_group">Blood Group Required</label>
            <select id="blood_group" name="blood_group" required>
                <option value="">--Select--</option>
                <option value="A+">A+</option>
                <option value="A-">A-</option>
                <option value="B+">B+</option>
                <option value="B-">B-</option>
                <option value="O+">O+</option>
                <option value="O-">O-</option>
                <option value="AB+">AB+</option>
                <option value="AB-">AB-</option>
            </select>

            <label for="city">City</label>
            <input type="text" id="city" name="city" required>

            <label for="dob">Date of Birth</label>
            <input type="date" id="dob" name="dob" required>

            <label for="adhar">Aadhar Number</label>
            <input type="text" id="adhar" name="adhar" required pattern="[0-9]{12}" title="Enter 12-digit Aadhar number">

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required minlength="6" pattern="(?=.*\d)(?=.*[a-z]).{8,}" title="Must contain at least one number and lowercase letter, and at least 8 or more characters">
            <%@ page import="java.sql.*, com.db.DBConnection" %>

<label for="hospital">Hospital</label>
<select id="hospital" name="hospitalId" required>
    <option value="">-- Select Hospital --</option>
<%
    Connection con = DBConnection.getConnection();
    Statement st = con.createStatement();
    ResultSet rs = st.executeQuery("SELECT hospital_id, hospital_name FROM hospital");
    while (rs.next()) {
%>
    <option value="<%= rs.getInt("hospital_id") %>">
        <%= rs.getString("hospital_name") %>
    </option>
<%
    }
    con.close();
%>
</select>


            <label>Gender</label>
            <input type="radio" id="male" name="gender" value="Male" required>
            <label for="male" style="display:inline;">Male</label>
            <input type="radio" id="female" name="gender" value="Female">
            <label for="female" style="display:inline;">Female</label>
            <input type="radio" id="other" name="gender" value="Other">
            <label for="other" style="display:inline;">Other</label>

            <button type="submit">Register</button>
        </form>
    </div>
</body>
</html>
