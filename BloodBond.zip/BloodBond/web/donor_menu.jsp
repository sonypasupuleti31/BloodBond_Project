<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Donor Menu - BloodBond</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #FFF8F6;
            color: #2D2D2D;
        }

        header {
            background-color: #B30000;
            color: #FFFFFF;
            padding: 20px 0;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: 700;
        }

        nav {
            background-color: #FF6B6B;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        nav ol {
            list-style: none;
            margin: 0;
            padding: 12px 0;
            display: flex;
            justify-content: center;
        }

        nav ol li {
            margin: 0 20px;
            font-weight: 600;
        }

        nav ol li a {
            color: white;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 6px;
            transition: all 0.3s ease;
        }

        nav ol li a:hover, nav ol li.active a {
            background-color: #B30000;
        }

        .content {
            max-width: 900px;
            margin: 40px auto;
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #B30000;
            margin-bottom: 24px;
        }
    </style>
</head>
<body>

    <!-- Header -->
    <header>
        <h1>BloodBond - Donor Dashboard</h1>
    </header>

    <!-- Navigation -->
    <nav>
        <ol>
            <li class="active"><a href="donor_menu.jsp">Home</a></li>
            <li><a href="blood_needed.jsp">Needed People</a></li>
            <li><a href="logout.jsp">Logout</a></li>
        </ol>
    </nav>

<!--    <div class="content">
        <h2>Welcome Donor!</h2>
        <p>Here you can view the people in your city who require blood. Manage your donations and check requests.</p>
    </div>-->

</body>
</html>
