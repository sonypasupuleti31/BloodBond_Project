<%@ page import="java.sql.*, com.db.DBConnection" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>View All Donors - BloodBond</title>
    <style>
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: #fff8f6;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        .container {
            width: 80%;
            max-width: 900px;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            text-align: center;
        }

        h2 {
            color: #B30000;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: left;
        }

        th {
            background-color: #B30000;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <br/>
    <jsp:include page="admin_menu.jsp"></jsp:include>
    <div class="container">
        <h2>All Donors</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Blood Group</th>
                    <th>City</th>
                    <th>Mobile</th>
                    <th>Email</th>
                </tr>
            </thead>
            <tbody>
                <%
                    Connection con = null;
                    PreparedStatement ps = null;
                    ResultSet rs = null;
                    try {
                        con = DBConnection.getConnection();
                        ps = con.prepareStatement("SELECT id, name, blood_group, city, mobile, email FROM donor ORDER BY id ASC");
                        rs = ps.executeQuery();
                        while(rs.next()) {
                %>
                <tr>
                    <td><%= rs.getInt("id") %></td>
                    <td><%= rs.getString("name") %></td>
                    <td><%= rs.getString("blood_group") %></td>
                    <td><%= rs.getString("city") %></td>
                    <td><%= rs.getString("mobile") %></td>
                    <td><%= rs.getString("email") %></td>
                </tr>
                <%
                        }
                    } catch(Exception e) {
                        out.println("<tr><td colspan='6' style='color:red;'>Error: " + e.getMessage() + "</td></tr>");
                    } finally {
                        if(rs!=null) rs.close();
                        if(ps!=null) ps.close();
                        if(con!=null) con.close();
                    }
                %>
            </tbody>
        </table>
    </div>
</body>
</html>
