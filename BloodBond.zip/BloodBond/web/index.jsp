<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BloodBond - Smart Blood Donation Platform</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', sans-serif;
            background-color: #FFF8F6; /* soft pink tone */
            color: #2D2D2D;
            line-height: 1.6;
        }
        main {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
        }
        section {
            background-color: #FFFFFF;
            padding: 32px;
            margin-bottom: 24px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        section:hover {
            transform: translateY(-4px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }
        h2 {
            color: #B30000; /* blood red */
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 16px;
            position: relative;
        }
        h2::after {
            content: '';
            width: 60px;
            height: 3px;
            background-color: #FF6B6B;
            position: absolute;
            bottom: -8px;
            left: 0;
            border-radius: 2px;
        }
        p {
            font-size: 16px;
            margin-bottom: 16px;
        }
        ul {
            padding-left: 20px;
            list-style-type: none;
        }
        ul li {
            margin-bottom: 8px;
            font-size: 16px;
        }
        .roles-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 24px;
            margin-top: 16px;
        }
        .roles-grid div {
            background-color: #FFF0F0;
            padding: 16px;
            border-radius: 8px;
            transition: 0.3s;
        }
        .roles-grid div:hover {
            background-color: #FFE3E3;
            transform: translateY(-3px);
        }
        img {
            max-width: 100%;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        footer {
            text-align: center;
            padding: 24px;
            border-top: 1px solid #E7E2DE;
            font-size: 14px;
            background-color: #FFFFFF;
            color: #6B6B6B;
        }
        @media (max-width: 768px) {
            section {
                padding: 24px;
            }
            h2 {
                font-size: 24px;
            }
            p {
                font-size: 15px;
            }
        }
    </style>
</head>
<body>
    <jsp:include page="homemenu.jsp"></jsp:include>

    <main>
        <!-- Introduction -->
        <section>
            <h2>Welcome to BloodBond</h2>
            <p>
                <b>BloodBond</b> is an online platform connecting blood donors, receivers, and hospitals.
                It ensures quick, safe, and transparent blood donation and request management using a
                centralized database and secure communication.
            </p>
        </section>

        <!-- Objectives -->
        <section>
            <h2>Objectives</h2>
            <ul>
                <li>Provide a digital bridge between blood donors and seekers.</li>
                <li>Enable blood banks to manage their stock efficiently.</li>
                <li>Promote awareness through donation camps and alerts.</li>
                <li>Ensure transparency and trust between users and hospitals.</li>
            </ul>
        </section>

        <!-- Roles -->
        <section>
            <h2>System Roles</h2>
            <div class="roles-grid">
                <div>
                    <h3>Donor</h3>
                    <p>Registers to donate blood, updates profile, and receives donation requests or alerts.</p>
                </div>
                <div>
                    <h3>Receiver</h3>
                    <p>Searches for available blood, sends requests, and tracks request status.</p>
                </div>
                <div>
                    <h3>Admin / Blood Bank</h3>
                    <p>Manages donors, requests, and blood stock. Can post camps and send emergency notifications.</p>
                </div>
            </div>
        </section>

        <!-- System Architecture -->
        <section>
            <h2>System Architecture</h2>
            <p>
                BloodBond uses a client-server architecture built with Java Servlets, JSP, JDBC, and MySQL.
                It securely handles donor and receiver data, providing role-based access and efficient data flow.
            </p>
            <div style="text-align:center;">
                <img src="images/bloodbond_architecture.png" alt="System Architecture Diagram">
            </div>
        </section>

        <!-- Footer -->
        <footer>
            © 2025 BloodBond | Smart Blood Donation Management System
        </footer>
    </main>
</body>
</html>
